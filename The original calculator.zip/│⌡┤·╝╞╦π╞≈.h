//
// Created by Admin on 25-5-24.
//

#ifndef 初代计算器_H
#define 初代计算器_H



class 初代计算器 {

};



#endif //初代计算器_H
